This is prepared for Microsoft Visual C++ 2008 Express Edition.

If you want to compile Nitro_Texture_Converter with other tools, download latest versions of libpng and zlib, compile them with your compiler and link them to Nitro_Texture_Converter.

http://www.libpng.org/pub/png/
http://www.info-zip.org/pub/infozip/zlib/